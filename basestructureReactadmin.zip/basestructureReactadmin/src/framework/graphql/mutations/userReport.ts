import { gql } from '@apollo/client';

export const CHANGE_USER_REPORT = gql``;
