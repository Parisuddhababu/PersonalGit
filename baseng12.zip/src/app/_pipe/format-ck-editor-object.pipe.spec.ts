import { FormatCkEditorObjectPipe } from './format-ck-editor-object.pipe';

describe('FormatCkEditorObjectPipe', () => {
  it('create an instance', () => {
    const pipe = new FormatCkEditorObjectPipe();
    expect(pipe).toBeTruthy();
  });
});
