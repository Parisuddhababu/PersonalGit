import { MultiCheckboxValidationDirective } from './multi-checkbox-validation.directive';

describe('MultiCheckboxValidationDirective', () => {
  it('should create an instance', () => {
    const directive = new MultiCheckboxValidationDirective();
    expect(directive).toBeTruthy();
  });
});
