import { PhoneMaskDirective } from './phone-mask.directive';

describe('PhoneMaskDirective', () => {
  it('should create an instance', () => {
    const directive = new PhoneMaskDirective();
    expect(directive).toBeTruthy();
  });
});
