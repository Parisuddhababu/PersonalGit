export class Cms {
  constructor(public page_title: object, public description: object, public meta_keywords: object, public meta_description: object) {}
}
