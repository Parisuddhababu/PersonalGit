export class Email {
  constructor(public email_subject: string, public email_body: string, public status: string) {}
}
