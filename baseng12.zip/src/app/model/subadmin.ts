export class Subadmin {
  constructor(
    public fullname: string,
    public email: string,
    public role: string,
    public created_at: string,
    public updated_at: string,
    public status: string
  ) {}
}
