export class Manageuser {
  constructor(
    public first_name: string,
    public username: string,
    public email: string,
    public gender: string,
    public date_of_birth: string,
    public phone_number: string,
    public created_at: string,
    public updated_at: string,
    public status: string
  ) {}
}
