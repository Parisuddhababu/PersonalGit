export class Faq {
  constructor(public answer: any, public faq_topic: any, public question: any, public slug: string, public status: string) {}
}
