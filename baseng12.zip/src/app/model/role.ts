export class Role {
  constructor(public name: string, public status: string) {}
}
