import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-manage-ruleset',
  templateUrl: './manage-ruleset.component.html',
  styleUrls: ['./manage-ruleset.component.scss'],
})
export class ManageRulesetComponent implements OnInit {
  constructor() {}

  ngOnInit() {}
}
