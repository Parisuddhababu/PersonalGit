import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-manage-survey',
  templateUrl: './manage-survey.component.html',
  styleUrls: ['./manage-survey.component.scss'],
})
export class ManageSurveyComponent implements OnInit {
  constructor() {}

  ngOnInit() {}
}
