import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-manage-offer',
  templateUrl: './manage-offer.component.html',
  styleUrls: ['./manage-offer.component.scss'],
})
export class ManageOfferComponent implements OnInit {
  constructor() {}

  ngOnInit() {}
}
