import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bs-media',
  templateUrl: './bs-media.component.html',
  styleUrls: ['./bs-media.component.scss'],
})
export class BsMediaComponent implements OnInit {
  constructor() {}

  ngOnInit() {}
}
