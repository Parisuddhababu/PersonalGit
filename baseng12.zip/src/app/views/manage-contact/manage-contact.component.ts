import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-manage-contact',
  templateUrl: './manage-contact.component.html',
  styleUrls: ['./manage-contact.component.scss'],
})
export class ManageContactComponent implements OnInit {
  constructor() {}

  ngOnInit() {}
}
