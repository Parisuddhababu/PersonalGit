import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-user-survey',
  templateUrl: './user-survey.component.html',
  styleUrls: ['./user-survey.component.scss'],
})
export class UserSurveyComponent implements OnInit {
  constructor() {}

  ngOnInit() {}
}
