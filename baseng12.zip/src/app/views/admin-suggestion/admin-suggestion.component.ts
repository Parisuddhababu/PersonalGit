import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admin-suggestion',
  templateUrl: './admin-suggestion.component.html',
  styleUrls: ['./admin-suggestion.component.scss'],
})
export class AdminSuggestionComponent implements OnInit {
  constructor() {}

  ngOnInit() {}
}
