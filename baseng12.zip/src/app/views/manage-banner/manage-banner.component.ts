import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-manage-banner',
  templateUrl: './manage-banner.component.html',
  styleUrls: ['./manage-banner.component.scss'],
})
export class ManageBannerComponent implements OnInit {
  constructor() {}

  ngOnInit() {}
}
