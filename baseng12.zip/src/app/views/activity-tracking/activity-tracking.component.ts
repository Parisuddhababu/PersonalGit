import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-activity-tracking',
  templateUrl: './activity-tracking.component.html',
  styleUrls: ['./activity-tracking.component.scss'],
})
export class ActivityTrackingComponent implements OnInit {
  constructor() {}

  ngOnInit() {}
}
