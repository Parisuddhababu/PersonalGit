import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-user-suggestion',
  templateUrl: './user-suggestion.component.html',
  styleUrls: ['./user-suggestion.component.scss'],
})
export class UserSuggestionComponent implements OnInit {
  constructor() {}

  ngOnInit() {}
}
