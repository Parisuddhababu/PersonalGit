import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-manage-event',
  templateUrl: './manage-event.component.html',
  styleUrls: ['./manage-event.component.scss'],
})
export class ManageEventComponent implements OnInit {
  constructor() {}

  ngOnInit() {}
}
