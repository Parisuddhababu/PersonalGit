export const environment = {
  production: true,
  apiEndpoint: 'https://baselumenphp8.demo.brainvire.dev',
  apiAdminVersion: '/admin/api/v1',
  apiFrontVersion: '/front/api/v1',
};
