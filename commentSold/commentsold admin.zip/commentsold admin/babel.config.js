module.exports = function () {
    return {
        plugins: ['macros'],
    }
}