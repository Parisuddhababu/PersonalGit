import React from 'react';

const Dashboard = () => {
	return (
		<div className='h-full flex justify-center items-center'>
			<div className=''>
				<div className='flex justify-center items-center text-primary opacity-70'>
					<div>
						<h2>{('WHIMarketing DASH BOARD')}</h2>
					</div>
				</div>
			</div>
		</div>
	);
};
export default Dashboard;
