export type TopCardProps = {
	title: string;
	value: string | number;
};
