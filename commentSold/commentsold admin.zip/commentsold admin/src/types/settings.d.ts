export type CreateSettings = {
	sessionTime: string;
	influencerCount: string;
	sessionCount:string;
};

export type FileDataProps = {
	name: string;
};
