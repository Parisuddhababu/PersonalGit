import Content from './content/Content';
import Footer from './footer/Footer';
import Header from './header/Header';
import Loader from './loadingIndicator/Loader';
import Sidebar from './sidebar/Sidebar';

export { Content, Footer, Header, Sidebar, Loader };
