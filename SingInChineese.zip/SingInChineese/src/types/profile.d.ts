export type ProfileResponse = {
	email: string;
	firstName: string;
	id: number;
	lastName: string;
	uuid: string;
};
